﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Poner a prueba HTTPS
//Josè M de Abongüez
//20 enero 2021

namespace WebServSSL_TLS
{
    public partial class Form1 : Form
    {
        //VARIABLES GLOBALES para Form1
        phpWebService phpService = new phpWebService();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnT1v1_Click(object sender, EventArgs e)
        {
            //Invoca el servicio, captura response y lo presenta en pantalla
            lblT1v1.Text = phpService.phpRequest();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Establecer el protocolo de comunicación desde el init
            //En este caso es estríctamente HTTPS
            phpService.SetSecurityProtocol();

        }
    }
}
