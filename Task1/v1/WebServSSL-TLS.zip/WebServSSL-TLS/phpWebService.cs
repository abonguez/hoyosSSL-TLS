﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//ADDED Required namespaces/resources for webservices
using System.Net;
using System.IO;

namespace WebServSSL_TLS
{
    class phpWebService
    {
        public string responseStored = "";

        public string phpRequest()
        {
         
         //SSL/TLS requerido para manejar certificados y keys
         //Lo ideal es setearlo desde el inicio   
         //System.Net.ServicePointManager.ServerCertificateValidationCallback = (senderX, certificate, chain, sslPolicyErrors) => { return true; };


            //4 pasos para conexión y procesamiento

            //1. Create a WebRequest
           
            //TEST en localhost https
            WebRequest webRequest = WebRequest.Create("https://localhost/v1/hello.php");

           
            //2. Tipo de interacción
            webRequest.Method = "GET";

            //3. Capturar lo que el servicio nos envía
            WebResponse webResponse = webRequest.GetResponse();

            //4. Interpretar la data y hacerla legible
            Stream dataStream = webResponse.GetResponseStream();
            StreamReader reader = new StreamReader(dataStream);
            string responseFromServer = reader.ReadToEnd();

            responseStored = responseFromServer;

            //LIMPIAR EL SISTEMA/RAM
            reader.Close();
            dataStream.Close();
            webResponse.Close();

            return responseStored; // + " : directa";
                                          
        }

        //El protocolo se debe establecer antes de init los sockets
        public void SetSecurityProtocol()
        {
           System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

           System.Net.ServicePointManager.ServerCertificateValidationCallback = (senderX, certificate, chain, sslPolicyErrors) => { return true; };

        }

    }
}
