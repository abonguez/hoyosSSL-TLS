﻿namespace WebServSSL_TLS
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnT1v1 = new System.Windows.Forms.Button();
            this.lblT1v1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnT1v1
            // 
            this.btnT1v1.Location = new System.Drawing.Point(33, 35);
            this.btnT1v1.Name = "btnT1v1";
            this.btnT1v1.Size = new System.Drawing.Size(121, 36);
            this.btnT1v1.TabIndex = 0;
            this.btnT1v1.Text = "Call ..v1/hello";
            this.btnT1v1.UseVisualStyleBackColor = true;
            this.btnT1v1.Click += new System.EventHandler(this.btnT1v1_Click);
            // 
            // lblT1v1
            // 
            this.lblT1v1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblT1v1.ForeColor = System.Drawing.Color.Lime;
            this.lblT1v1.Location = new System.Drawing.Point(178, 37);
            this.lblT1v1.Name = "lblT1v1";
            this.lblT1v1.Size = new System.Drawing.Size(209, 33);
            this.lblT1v1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label1.Location = new System.Drawing.Point(178, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "RESPONSES";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(495, 410);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblT1v1);
            this.Controls.Add(this.btnT1v1);
            this.Name = "Form1";
            this.Text = "Test Calls to HTTPS SSL/TLS Services";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnT1v1;
        private System.Windows.Forms.Label lblT1v1;
        private System.Windows.Forms.Label label1;
    }
}

