﻿<?php

//Hola Mundo: Este servicio solo devuelve "world" cuando lo invocan
//Se le pondrá aprueba con dos metodologías de invocación:
// 1. Un DOCTYPE HTML
// 2. Un ejecutable con UI/UX
//NOTA: Estas pruebas se harán en una plataforma HTTPS
//		En este proyecto se está utilizando WAMP Server en localhost:443
//		El servidor está corriendo SSL/TLS Con Certificados y Private.Keys
//		creados con la herramienta OpenSSL. 
//		El certificado es self-signed.

// Josè M de Abongüez
// ...www/v1/hello.php

$HolaMundo = "world";

echo $HolaMundo;// ////

?>