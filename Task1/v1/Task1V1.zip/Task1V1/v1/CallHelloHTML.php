﻿<!--
- Esta archivo tiene como propósito invocar el
  servicio de hello.php
- Ambos archivos deben estar en el mismo nivel jerárquico.
// Josè M de Abongüez
// invoca a ...www/v1/hello.php
-->

<!DOCTYPE html>
<html>
<body>

<a Test $GET Hola Mundo</a>

<?php require_once 'hello.php' ?>


</body>
</html>
