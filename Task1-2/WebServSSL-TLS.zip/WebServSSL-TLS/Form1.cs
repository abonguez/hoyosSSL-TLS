﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//ADDED
using System.Net;
using System.IO;


//Poner a prueba HTTPS
//Josè M de Abongüez
//20 enero 2021

namespace WebServSSL_TLS
{
    public partial class Form1 : Form
    {
        //VARIABLES GLOBALES para Form1
        phpWebService phpService = new phpWebService();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnT1v1_Click(object sender, EventArgs e)
        {
            //Invoca el servicio, captura response y lo presenta en pantalla
            lblT1v1.Text = phpService.phpRequest();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Establecer el protocolo de comunicación desde el init
            //En este caso es estríctamente HTTPS
            phpService.SetSecurityProtocol();

        }

        private void btnPostPhp_Click(object sender, EventArgs e)
        {
            try
            {
                string data0 = txtData0.Text;
                string data1 = txtData1.Text;

                ASCIIEncoding encodeData = new ASCIIEncoding();
                string postData = "data0=" + data0 + "&data1=" + data1; //debe ser consistente con el php
                byte[] LaData = encodeData.GetBytes(postData);

                //1. Create a WebRequest

                //TEST en localhost https
                WebRequest webRequest = WebRequest.Create("https://localhost/v2/hello.php");


                //2. Tipo de interacción
                webRequest.Method = "POST";
                webRequest.ContentType = "application/x-www-form-urlencoded";
                webRequest.ContentLength = LaData.Length;

                Stream outStream = webRequest.GetRequestStream();
                outStream.Write(LaData, 0, LaData.Length);
                outStream.Close();


                //3. Capturar lo que el servicio nos envía
                WebResponse webResponse = webRequest.GetResponse();

                //4. Interpretar la data y hacerla legible
                Stream dataStream = webResponse.GetResponseStream();
                StreamReader reader = new StreamReader(dataStream);
                string responseFromServer = reader.ReadToEnd();

                lblPostPhp.Text = responseFromServer;
                //textBox1.Text = responseFromServer;

                //LIMPIAR EL SISTEMA/RAM
                reader.Close();
                dataStream.Close();
                webResponse.Close();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error : " + ex.Message);
            }

        }
    }
}
